# Engineering Patterns & Lessons Learned

> Use this document to 'train' your agents on project-specific findings.

## 🟢 Mandatory Patterns
- **Time Handling**: Always use ISO-8601 with explicit T00:00:00 for local day boundaries.
- **Data Integrity**: Never overwrite history; use `ON CONFLICT` for updates.
- **API Design**: Return descriptive error messages, never empty arrays for errors.

## 🔴 Known Gotchas
- [Add findings as they emerge during debugging here]

---
*Reference: SunShift EMS Session 2026-05-04*
