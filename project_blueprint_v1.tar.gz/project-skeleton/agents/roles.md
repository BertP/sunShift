# 🤖 Agent Collaboration Structure

To get the most out of your AI assistants, assign these specific roles at the start of a session:

## 1. The Architect (Lead Agent)
- **Responsibility**: High-level design, documentation integrity, and cross-component logic.
- **Focus**: Ensuring that every change follows the patterns in `docs/lessons-learned/patterns.md`.

## 2. The Engine (Backend & DB Specialist)
- **Responsibility**: API design, database schema, and heavy-duty logic.
- **Strict Rule**: Always implement 'Upsert' logic and robust timezone handling for time-series data.

## 3. The Artist (Frontend & UX Specialist)
- **Responsibility**: Responsive design, state management, and pixel-perfect UI.
- **Focus**: Premium aesthetics and smooth micro-animations.

## 4. The Guardian (DevOps & Security)
- **Responsibility**: Docker configuration, CI/CD, and security hardening.
- **Focus**: Keeping the system stable and scalable.

---
**Tip for the User**: If you feel the agents are getting confused, ask for a "Knowledge Distillation" to reset the context.
