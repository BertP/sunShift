# [Project Name]

> Brief one-sentence value proposition of the project.

## 🚀 Quick Start
1. `cp .env.example .env`
2. `docker compose up --build -d`
3. Access at `http://localhost:[PORT]`

## 📚 Documentation Index
- **Architecture**: [docs/architecture/overview.md](docs/architecture/overview.md)
- **Engineering Patterns**: [docs/lessons-learned/patterns.md](docs/lessons-learned/patterns.md)
- **Deployment Guide**: [docs/operations/deployment.md](docs/operations/deployment.md)

## 🤖 Agent Collaboration
This project is designed for AI-human pair programming. Refer to [agents/roles.md](agents/roles.md) for optimized agent instructions.

---
*Created with SunShift Blueprint*
